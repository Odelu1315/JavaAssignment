package com.dal.travelproj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TravelprojApplicationTests {

	@Test
	void contextLoads() {
	}

}
